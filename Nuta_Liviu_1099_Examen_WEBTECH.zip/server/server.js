require('dotenv').config({})
const express= require('express')
const Sequelize = require('sequelize')
const bodyParser = require('body-parser')
const cors=require('cors')
const { Router } = require('express')
const { path } = require('path')

let sequelize

if(process.env.NODE_ENV === 'development'){
    sequelize = new Sequelize({
        dialect: 'sqlite',
        storage:"sample.db",
        define: {
            timestamps:false
        }
    })
}else{
    sequelize = new Sequelize(process.env.DATABASE_URL, {
        dialect: 'postgres',
        protocol: 'postgres',
        dialectOptions: {
            ssl: {
                require: true,
                rejectUnauthorized: false
            }
        }
    })
}
//Definirea entitatilor in structura bazei de date
const FavouriteList = sequelize.define('list',{
    description: {
        type: Sequelize.STRING,
        validate: {
            len: [3, 500]
        },
        allowNull: false
    },
    date:{
        type: Sequelize.DATE,
        allowNull: false
    }
})

const Video = sequelize.define('video',{
    vdescription: {
        type: Sequelize.STRING,
        validate: {
            len: [5, 500]
        },
        allowNull: false
    },
    title:{
        type: Sequelize.STRING,
        validate: {
            len: [5, 500]
        },
        allowNull: false
    },
    url:{
        type: Sequelize.STRING,
        validate: {
            isUrl: true
        },
        allowNull: false
    }
})

FavouriteList.hasMany(Video)

let router = express.Router()
const app = express()
app.use(cors())
app.use(bodyParser.json())
app.use(express.static('build'))

//Ruta pentru crearea de baza de date la pornirea aplicatiei pentru prima data
app.get('/sync', async (req,res) =>{
    try{
        await sequelize.sync({force:true})
        res.status(201).json({message:"tables created"})
    } catch(err) {
        console.warn(err)
        res.status(500).json({message:'some error occured'})
    }
})

//Route for getting all favourite lists from database
app.get('/lists', async (req, res) => {
    try {
        const lists = await FavouriteList.findAll()
        res.status(200).json(lists)
    } catch (err) {
        console.warn(err)
        res.status(500).json({ message: "Some error occured while getting the favourite lists" })
    }
})

//Route for adding a favourite list in the database
app.post('/lists', async (req, res) => {
    try {
        const list = req.body
        await FavouriteList.create(list)
        res.status(201).json({message: "Favourite list created"})
    } catch (err) {
        console.warn(err)
        res.status(500).json({message: "Some error occured while creating the favourite list"})
    }
})

//Route for getting a certain favourite list from the database
app.get('/lists/:lid', async(req,res) => {
    try{
        const list = await FavouriteList.findByPk(req.params.lid,{
            include: Video
        })
        if(list){
            res.status(200).json(list)
        } else{
            res.status(404).json({message:"List not found in the database"})
        }
    } catch(err) {
        console.warn(err)
        res.status(500).json({message:'Couldn\' get the list from the database'})
    }
})

//Route for editing a certain favourite list data
app.put('/lists/:lid', async(req,res) => {
    try{
        const list = await FavouriteList.findByPk(req.params.lid)
        if(list){
            await list.update(req.body,{ fields: ['description','date']})
            res.status(202).json({message : "The list was edited successfully"})
        } else{
            res.status(404).json({message:"List not found"})
        }
    } catch(err) {
        console.warn(err)
        res.status(500).json({message:'The list couldn\'t be edited'})
    }
})

//Route for deleting a certain list
app.delete('/lists/:lid', async(req,res) => {
    try{
        const list = await FavouriteList.findByPk(req.params.lid)
        if(list){
            await list.destroy()
            res.status(202).json({message : "The list was deleted"})
        } else{
            res.status(404).json({message:"List not found"})
        }
    } catch(err) {
        console.warn(err)
        res.status(500).json({message:'Couldn\' delete the list'})
    }
})

//Route for getting all the videos of a list
app.get('/lists/:lid/videos',async (req,res) => {
    try{
        const list = await FavouriteList.findByPk(req.params.lid)
        if(list){
            const videos = await list.getVideos()
            res.status(200).json(videos)
        } else{
            res.status(404).json({message:"List not found"})
        }
    } catch(err) {
        console.warn(err)
        res.status(500).json({message:'Some error occured while getting the videos'})
    }
})

//Route for adding a video to a list
app.post('/lists/:lid/videos',async (req,res) => {
    try{
        const list = await FavouriteList.findByPk(req.params.lid)
        if(list){
            const video = req.body
            video.listId = list.id
            await Video.create(video)
            res.status(200).json({message: 'Video added succesfully'})
        } else{
            res.status(404).json({message:"List not found"})
        }
    } catch(err) {
        console.warn(err)
        res.status(500).json({message:'Some error occured while adding the video'})
    }
})

//Route for getting a certain video for a certain list
app.get('/lists/:lid/videos/:vid',async (req,res) => {
    try{
        const list = await FavouriteList.findByPk(req.params.lid)
        if(list){
            const videos = await list.getVideos({where: {
                id:req.params.vid
            }})
            const video = videos.shift()
            if(video){
                res.status(200).json(video)
            } else{
                res.status(404).json({message:"Video bot found"})
            }
        } else{
            res.status(404).json({message:"List not found"})
        }
    } catch(err) {
        console.warn(err)
        res.status(500).json({message:'Some error occured while getting the video'})
    }
})

//Route for editing a certain video for a certain list
app.put('/lists/:lid/videos/:vid',async (req,res) => {
    try{
        const list = await FavouriteList.findByPk(req.params.lid)
        if(list){
            const videos = await list.getVideos({where: {
                id:req.params.vid
            }})
            const video = videos.shift()
            if(video){
                await video.update(req.body)
                res.status(202).json({message : "Video edited"})
            } else{
                res.status(404).json({message:"Video not found"})
            }
        } else{
            res.status(404).json({message:"List not found"})
        }
    } catch(err) {
        console.warn(err)
        res.status(500).json({message:'Some error occured while editing the video'})
    }
})

//Route for deleting the video of a list
app.delete('/lists/:lid/videos/:vid',async (req,res) => {
    try{
        const list = await FavouriteList.findByPk(req.params.lid)
        if(list){
            const videos = await list.getVideos({where: {
                id:req.params.vid
            }})
            const video = videos.shift()
            if(video){
                await video.destroy()
                res.status(202).json({message : "Video has been deleted"})
            } else{
                res.status(404).json({message:"Video not found"})
            }
        } else{
            res.status(404).json({message:"List not found"})
        }
    } catch(err) {
        console.warn(err)
        res.status(500).json({message:'Some error occured while deleting the video'})
    }
})

router.route('/').get(async (req, res) => {
    let path = path.resolve();
    res.sendFile(path.join(path, "build", "index.html"))
})

app.listen(process.env.PORT, async () => {
    await sequelize.sync({alter: true})
})

//app.listen(8080)