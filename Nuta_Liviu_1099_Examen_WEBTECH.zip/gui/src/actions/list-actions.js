import { SERVER } from '../config/global'

export const GET_LISTS = 'GET_LISTS'
export const ADD_LISTS = 'ADD_LISTS'
export const EDIT_LISTS = 'EDIT_LISTS'
export const DELETE_LISTS = 'DELETE_LISTS'

export function getLists () {
    return {
        type: GET_LISTS,
        payload: async () => {
            const response = await fetch(`${SERVER}/lists`)
            const data = await response.json()
            return data
        }
    }
}

export function addList (list) {
    return {
        type: ADD_LISTS,
        payload: async () => {
            await fetch(`${SERVER}/lists`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(list)
            })
            const response = await fetch(`${SERVER}/lists`)
            const data = await response.json()
            return data
        }
    }
}

export function editList (listId, list) {
    return {
        type: EDIT_LISTS,
        payload: async () => {
            await fetch(`${SERVER}/lists/${listId}`, {
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(list)
            })
            const response = await fetch(`${SERVER}/lists`)
            const data = await response.json()
            return data
        }
    }
}

export function deleteList (listId) {
    return {
        type: DELETE_LISTS,
        payload: async () => {
            await fetch(`${SERVER}/lists/${listId}`, {
                method: 'DELETE',
            })
            const response = await fetch(`${SERVER}/lists`)
            const json = await response.json()
            return json
        }
    }
}