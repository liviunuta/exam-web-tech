import { SERVER } from '../config/global'

export const GET_VIDEOS = 'GET_VIDEOS'
export const ADD_VIDEOS = 'ADD_VIDEOS'
export const EDIT_VIDEOS = 'EDIT_VIDEOS'
export const DELETE_VIDEOS = 'DELETE_VIDEOS'

export function getVideos (listId) {
    return {
        type: GET_VIDEOS,
        payload: async () => {
            const response = await fetch(`${SERVER}/lists/${listId}/videos`)
            const data = await response.json()
            return data
        }
    }
}

export function addVideo (listId, video) {
    return {
        type: ADD_VIDEOS,
        payload: async () => {
            await fetch(`${SERVER}/lists/${listId}/videos`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(video)
            })
            const response = await fetch(`${SERVER}/lists/${listId}/videos`)
            const data = await response.json()
            return data
        }
    }
}

export function editVideo (listId, videoId, video) {
    return {
        type: EDIT_VIDEOS,
        payload: async () => {
            await fetch(`${SERVER}/lists/${listId}/videos/${videoId}`, {
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(video)
            })
            let response = await fetch(`${SERVER}/lists/${listId}/videos`)
            let data = await response.json()
            return data
        }
    }
}

export function deleteVideo (listId, videoId) {
    return {
        type: DELETE_VIDEOS,
        payload: async () => {
            await fetch(`${SERVER}/lists/${listId}/videos/${videoId}`, {
                method: 'DELETE',
            })
            let response = await fetch(`${SERVER}/lists/${listId}/videos`)
            let json = await response.json()
            return json
        }
    }
}
