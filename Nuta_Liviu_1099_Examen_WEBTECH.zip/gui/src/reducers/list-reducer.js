const INITIAL_STATE = {
    favouriteList: [],
    error: null,
    fetching: false,
    fetched: false
}

export default function reducer(state = INITIAL_STATE, action){
    switch (action.type) {
        case 'GET_LISTS_PENDING':
        case 'ADD_LISTS_PENDING':
        case 'EDIT_LISTS_PENDING':
        case 'DELETE_LISTS_PENDING':
            return {...state, error: null, fetching: true, fetched: false}
        case 'GET_LISTS_FULFILLED':
        case 'ADD_LISTS_FULFILLED':
        case 'EDIT_LISTS_FULFILLED':
        case 'DELETE_LISTS_FULFILLED':
            return {...state, favouriteList: action.payload, fetching: false, fetched: true}
        case 'GET_LISTS_REJECTED':
        case 'ADD_LISTS_REJECTED':
        case 'EDIT_LISTS_REJECTED':
        case 'DELETE_LISTS_REJECTED':    
            return {...state, error: action.payload, fetching: false, fetched: false}
        default:
            return state
    }
}