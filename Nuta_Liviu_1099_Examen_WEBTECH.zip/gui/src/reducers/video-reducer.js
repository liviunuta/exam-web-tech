const INITIAL_STATE = {
    videoList: [],
    error: null,
    fetching: false,
    fetched: false
}

export default function reducer(state = INITIAL_STATE, action){
    switch (action.type) {
        case 'GET_VIDEOS_PENDING':
        case 'ADD_VIDEOS_PENDING':
        case 'EDIT_VIDEOS_PENDING':
        case 'DELETE_VIDEOS_PENDING':
            return {...state, error: null, fetching: true, fetched: false}
        case 'GET_VIDEOS_FULFILLED':
        case 'ADD_VIDEOS_FULFILLED':
        case 'EDIT_VIDEOS_FULFILLED':
        case 'DELETE_VIDEOS_FULFILLED':
            return {...state, videoList: action.payload, fetching: false, fetched: true}
        case 'GET_VIDEOS_REJECTED':
        case 'ADD_VIDEOS_REJECTED':
        case 'EDIT_VIDEOS_REJECTED':
        case 'DELETE_VIDEOS_REJECTED':
            return {...state, error: action.payload, fetching: false, fetched: false}
        default:
            return state
    }
}