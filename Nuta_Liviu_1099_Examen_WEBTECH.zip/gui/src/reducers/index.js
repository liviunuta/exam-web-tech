import { combineReducers } from 'redux'
import list from './list-reducer'
import video from './video-reducer'

export default combineReducers({
    list, 
    video
})