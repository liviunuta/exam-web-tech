import { useEffect, useState } from 'react'
import { useSelector, shallowEqual, useDispatch } from 'react-redux'

import { DataTable } from 'primereact/datatable'
import { Column } from 'primereact/column'
import { Button } from 'primereact/button'
import { InputText } from 'primereact/inputtext'
import { Dialog } from 'primereact/dialog'

import {listActions} from '../actions'
import {videoActions} from '../actions'

const favouriteListSelector = state => state.list.favouriteList
const videoListSelector = state => state.video.videoList

let list_data = null

function FavouriteList() {
    const [isListDialogShown, setIsListDialogShown] = useState(false)
    const [description, setDescription] = useState('')
    const [date, setDate] = useState('')
    const [isNewList, setIsNewList] = useState(true)
    const [selectedList, setSelectedList] = useState(null)

    const [isVideosDialogShown, setIsVideosDialogShown] = useState(false)
    const [vdescription, setVDescription] = useState('')
    const [title, setTitle] = useState('')
    const [url, setUrl] = useState('')
    const [isNewVideo, setIsNewVideo] = useState(true)
    const [selectedVideo, setSelectedVideo] = useState(null)
    const [isNewVideoDialogShown, setIsNewVideoDialogShown] = useState(false)


    const favouriteList = useSelector(favouriteListSelector, shallowEqual)
    const videoList = useSelector(videoListSelector, shallowEqual)

    const dispatch = useDispatch()

    useEffect(() => {
        dispatch(listActions.getLists())
    }, [dispatch])



    const addNewList = () => {
        setIsListDialogShown(true)
        setDescription('')
        setDate(new Date())
        setSelectedList(null)
        setIsNewList(true)
    }

    const deleteList = (rowData) => {
        dispatch(listActions.deleteList(rowData.id))
    }

    const editList = (rowData) => {
        setSelectedList(rowData.id)
        setDescription(rowData.description)
        setIsListDialogShown(true)
        setIsNewList(false)
    }

    const saveList = () => {
        if(isNewList){
            dispatch(listActions.addList({description, date}))
        }else{
            dispatch(listActions.editList(selectedList, {description}))
        }
        setIsListDialogShown(false)
        setDescription('')
        setDate('')
        setSelectedList(null)
    }

    const hideDialog = () => {
        setIsListDialogShown(false)
    }

    const showVideos = (rowdata) => {
        setIsVideosDialogShown(true)
        dispatch(videoActions.getVideos(rowdata.id))
        list_data = rowdata
    }

    const hideVideosDialog = () => {
        setIsVideosDialogShown(false)
        list_data = null
    }

    const addNewVideo = () => {
        setIsVideosDialogShown(false)
        setIsNewVideoDialogShown(true)
        setTitle('')
        setVDescription('')
        setUrl('')
        setSelectedVideo(null)
        setIsNewVideo(true)
    }

    const deleteVideo = (rowData) => {
        dispatch(videoActions.deleteVideo(list_data.id, rowData.id))
    }

    const editVideo = (rowData) => {
        setSelectedVideo(rowData.id)
        setTitle(rowData.title)
        setVDescription(rowData.vdescription)
        setUrl(rowData.url)
        setIsNewVideoDialogShown(true)
        setIsNewVideo(false)
    }

    const hideAddVideoDialog = () => {
        setIsNewVideoDialogShown(false)
        list_data = null
    }

    const saveVideo = () => {
        if(isNewVideo == true){
            dispatch(videoActions.addVideo(list_data.id, {title, vdescription, url}))
        }else{
            dispatch(videoActions.editVideo(list_data.id, selectedVideo, {title, vdescription, url}))
        }
        setIsNewVideoDialogShown(false)
        setTitle('')
        setVDescription('')
        setUrl('')
        setSelectedVideo(null)
        list_data = null
    }



    const opsColumn = (rowData) => {
        return(
            <>
                <Button icon='pi pi-times' className='p-button-danger' onClick={() => deleteList(rowData)} />
                <Button icon='pi pi-pencil' className='p-button-warning' onClick={() => editList(rowData)} />
            </>
        )
    }

    const tableFooter = (
        <div>
            <Button label='Create new list' icon='pi pi-plus' onClick={addNewList}/>
        </div>
    )

    const addListDialogFooter = (
        <div>
            <Button label='Save' icon='pi pi-save' onClick={saveList}/>
        </div>
    )

    const videosColumn = (rowData) => {
        return(
            <>
                <Button icon='pi pi-eye' className='p-button-success' onClick={() => showVideos(rowData)} />
            </>
        )
    }

    const videosTableFooter = (
        <div>
            <Button label='Add video' icon='pi pi-plus' onClick={addNewVideo}/>
        </div>
    )

    const opsVideoColumn = (rowData) => {
        return(
            <>
                <Button icon='pi pi-times' className='p-button-danger' onClick={() => deleteVideo(rowData)} />
                <Button icon='pi pi-pencil' className='p-button-warning' onClick={() => editVideo(rowData)} />
            </>
        )
    }

    const addVideoDialogFooter = () => {
        return(
            <>
                <Button label='Save video' icon='pi pi-save' onClick={() => saveVideo(list_data)}/>
            </>
        )
    }

  return (
    <div>
        <DataTable value={favouriteList} footer={tableFooter}>
            <Column header='Description' field='description' sortable/>
            <Column header='Date' field='date' sortable/>
            <Column body={videosColumn} header='Favourite Videos'/>
            <Column body={opsColumn} />
        </DataTable>
        {
            isListDialogShown
                ?(
                    <Dialog visible={isListDialogShown} onHide={hideDialog} footer={addListDialogFooter} header='Add/Edit a list'>
                        <InputText onChange={ (evt) => setDescription(evt.target.value)} value={description} name='List Description' placeholder='Description here...' />
                    </Dialog>
                ) : null
        }
        {
            isVideosDialogShown
                ?(
                    <Dialog visible={isVideosDialogShown} onHide={hideVideosDialog} header='Favourite Videos'>
                        <DataTable value={videoList} footer={videosTableFooter}>
                            <Column header='Title' field='title' sortable/>
                            <Column header='Description' field='vdescription' sortable/>
                            <Column header='URL' field='url' />
                            <Column body={opsVideoColumn} />
                        </DataTable>
                    </Dialog>
                ): null
        }
        {
            isNewVideoDialogShown
            ?(
                <Dialog visible={isNewVideoDialogShown} onHide={hideAddVideoDialog} footer={addVideoDialogFooter} header='Add/edit a new video'>
                    <InputText onChange={ (evt) => setTitle(evt.target.value)} value={title} name='Video title' placeholder='Title here...' />
                    <InputText onChange={ (evt) => setVDescription(evt.target.value)} value={vdescription} name='Video description' placeholder='Description here...' />
                    <InputText onChange={ (evt) => setUrl(evt.target.value)} value={url} name='Video url' placeholder='Paste url here...' />
                </Dialog>
            ) : null
        }
    </div>
  );
}

export default FavouriteList;
