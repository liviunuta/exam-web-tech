import FavouriteList from './favourite-list'

function App() {
  return (
    <div>
      <FavouriteList />
    </div>
  );
}

export default App;
